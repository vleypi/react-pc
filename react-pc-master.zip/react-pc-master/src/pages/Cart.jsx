import React from 'react'

import {useDispatch} from 'react-redux'

function Cart() {
    const dispatch = useDispatch()
    React.useEffect(()=>{
    })
    return (
        <div>
            def
        </div>
    )
}

export default Cart
