import React from 'react'

function ResultNothing({resultValid}) {
    return (
        <div>
            Ничего не найдено...
        </div>
    )
}

export default ResultNothing
